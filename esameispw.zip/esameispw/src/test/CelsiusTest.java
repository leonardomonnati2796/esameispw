package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import logic.Convert;

public class CelsiusTest {
	
	@Test
	public void passwordTest() {

		Convert convert = new Convert();
		
		int output=convert.convertCelsiusFahrenheit(30);
		assertEquals(217, output);
	}
		
}
