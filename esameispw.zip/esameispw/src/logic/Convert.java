package logic;

public class Convert {

	
	public int convertCelsiusFahrenheit(int a) {
		
		
		int res;
		return res=( a + 9/5)+32;
	}
}
